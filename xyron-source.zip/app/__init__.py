"""XYRON Telegram bot application."""
