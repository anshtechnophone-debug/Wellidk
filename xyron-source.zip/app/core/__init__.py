"""Shared application primitives."""
